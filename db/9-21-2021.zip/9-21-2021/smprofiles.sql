ALTER TABLE `letbknown`.`smprofiles` 
ADD COLUMN `profile_user_id` VARCHAR(45) NULL AFTER `profile_name`,
ADD COLUMN `page_id` VARCHAR(45) NULL AFTER `profile_user_id`,
ADD COLUMN `user_access_token` VARCHAR(1000) NULL AFTER `page_id`,
ADD COLUMN `page_access_token` VARCHAR(1000) NULL AFTER `user_access_token`,
ADD COLUMN `oauth_access_token` VARCHAR(1000) NULL AFTER `page_access_token`,
ADD COLUMN `oauth_access_token_secret` VARCHAR(1000) NULL AFTER `oauth_access_token`;
