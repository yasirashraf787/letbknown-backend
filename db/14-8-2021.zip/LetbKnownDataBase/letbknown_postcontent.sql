CREATE DATABASE  IF NOT EXISTS `letbknown` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `letbknown`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: letbknown
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `postcontent`
--

DROP TABLE IF EXISTS `postcontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `postcontent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `profile` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `scheduled_date` datetime DEFAULT NULL,
  `sent_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid_fk_idx` (`user_id`),
  CONSTRAINT `uid_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postcontent`
--

LOCK TABLES `postcontent` WRITE;
/*!40000 ALTER TABLE `postcontent` DISABLE KEYS */;
INSERT INTO `postcontent` VALUES (2,4,'test db draft 10/8/21','sent','facebook','2021-07-29 20:46:17',NULL,'2021-08-10 14:33:08',NULL),(3,4,'last last test db','sent','facebook','2021-07-29 20:49:30',NULL,'2021-08-05 14:24:24',NULL),(4,4,'Testing post fb 30/7/21 new sent post to db','sent','facebook','2021-07-30 16:18:14',NULL,'2021-07-30 16:18:14',NULL),(5,4,'Test post monday aug 21','sent','facebook','2021-08-02 16:28:14',NULL,'2021-08-02 16:28:14',NULL),(6,4,'Draft post test 2/8/21 update','sent','facebook','2021-08-02 19:20:30',NULL,'2021-08-05 00:55:00',NULL),(9,4,'Set Updated data twitter 4/8/21 sent today 6/8/21','sent','twitter','2021-08-04 17:39:02',NULL,'2021-08-06 14:17:54',NULL),(10,4,'First scheduled post -sent post','sent','facebook','2021-08-05 16:50:01',NULL,'2021-08-06 13:55:00',NULL),(11,4,'Testing post - \"Long lived Access Token\" - 6/8/21','sent','facebook','2021-08-06 13:46:34',NULL,'2021-08-06 13:46:34',NULL),(12,4,'Testing post to facebook page','sent','facebook','2021-08-06 13:59:31',NULL,'2021-08-06 13:59:31',NULL),(13,4,'Testing post to twitter db','sent','twitter','2021-08-06 14:05:49',NULL,'2021-08-06 14:05:49',NULL),(14,4,'Scheduled Post LinkedIn - sent 6.8.2021','sent','linkedin','2021-08-06 14:50:04',NULL,'2021-08-06 15:34:30',NULL),(15,4,'Save post to drat - linkedIn sent now','sent','linkedin','2021-08-06 15:08:00',NULL,'2021-08-06 15:19:03',NULL),(16,4,'Testing post monday 9/8/21','sent','facebook','2021-08-09 09:36:16',NULL,'2021-08-09 09:36:16',NULL),(17,4,'Test post to fb test test','sent','facebook','2021-08-10 09:42:37',NULL,'2021-08-10 09:42:37',NULL),(18,4,'Testing post extended access token.','sent','facebook','2021-08-10 09:44:05',NULL,'2021-08-10 09:44:05',NULL),(19,4,'My scheduled post','sent','facebook','2021-08-10 14:56:30',NULL,'2021-08-10 14:59:00',NULL),(20,4,'Twitter draft content','draft','twitter','2021-08-10 15:03:18',NULL,NULL,'2021-08-10 15:03:18'),(21,4,'Scheduled Post test','sent','facebook','2021-08-11 12:29:12',NULL,'2021-08-11 13:16:00',NULL),(22,4,'2nd scheduled post test re-post','sent','facebook','2021-08-11 13:07:09','2021-08-11 13:23:00','2021-08-11 13:23:00','2021-08-11 13:23:00'),(23,4,'Scheduled post 3rd time','sent','facebook','2021-08-11 13:38:05','2021-08-11 13:40:00','2021-08-11 13:40:00','2021-08-11 13:40:00'),(24,4,'test post to twitter','sent','twitter','2021-08-13 13:54:30',NULL,'2021-08-13 13:54:30',NULL);
/*!40000 ALTER TABLE `postcontent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-14 20:54:39
